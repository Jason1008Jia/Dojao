#!/usr/bin/env bash
# ============================================================================
# dojao 电商场景造数 —— 一键跑（在集群节点 aliyun003 上执行，全程内网）
#
#   ./run.sh              # 装依赖 → 造 MySQL → 造 Hive
#   ./run.sh mysql        # 只造业务数据（MySQL dojao 库）
#   ./run.sh hive         # 只造行为日志（Hive dojao_test 库）
#   ./run.sh install      # 只装依赖
#
# 透传参数用 `--`：./run.sh mysql -- --reset
# 规模 / 分布全部在 config.py 里改，不必动代码。
# ============================================================================
set -euo pipefail
cd "$(dirname "$0")"

STEP="${1:-all}"
shift || true
if [ "${1:-}" = "--" ]; then shift; fi

case "$STEP" in
    install) ;;
    mysql|hive|all) python3 -m pip install -q -r requirements.txt ;;
    *) echo "用法：$0 [install|mysql|hive|all] [-- <额外参数>]" >&2; exit 2 ;;
esac

case "$STEP" in
    install) echo "依赖已就绪。" ;;
    mysql)   python3 gen_mysql.py "$@" ;;
    hive)    python3 gen_hive.py "$@" ;;
    all)     python3 gen_mysql.py "$@" && python3 gen_hive.py "$@" ;;
esac
